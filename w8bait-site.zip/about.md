---
layout: default
title: About
permalink: /about/
---

# About

W8BAIT is a creative brand focused on interactive experiences.
